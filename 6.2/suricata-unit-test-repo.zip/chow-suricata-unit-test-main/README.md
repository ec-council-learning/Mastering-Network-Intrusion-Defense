# chow-suricata-unit-test
Repo for testing GitHub Actions in CI based Unit Testing using Suricata Rules and Pcaps
